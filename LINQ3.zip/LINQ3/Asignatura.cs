﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ3
{
    internal class Asignatura
    {
        public int idAsignatura { get; set; }
        public string Nombre { get; set; }
        public int Credito { get; set; }
        public int Frecuencia { get; set; }
    }
}
