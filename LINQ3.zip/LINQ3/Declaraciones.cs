﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ3
{
    static class Declaraciones
    {
        public static List<Estudiante> ListaEstudiante = new List<Estudiante>();
        public static List<Asignatura> ListaAsignatura = new List<Asignatura>();
        public static List<Pago> ListaPagos = new List<Pago>();
        public static List<Est_Asig> ListaEstAsig = new List<Est_Asig>();
    }
}
