﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ3
{
    internal class Est_Asig
    {
        public int Carnet { get; set; }
        public int idAsignatura { get; set; }
    }
}
